import win32com.client
import pythoncom
import tkinter as tk
from tkinter import filedialog
import os
from .helpers import list_visio_drawings


class vDocClass:
    def __init__(self):
        self.visio = None
        self.app = None
        self.doc = None
        self.page = None
        self.win = None
        self.start_message()

    def start_message(self):
        docs = list_visio_drawings()
        doc_names = [f"{str(i)}. {doc.Name}" for i, doc in enumerate(docs)]
        docs_text = '\n'.join(doc_names)
        msg = 'Currently open Visio files:\n' + docs_text + '\n\n'
        msg += '''Use ".init" to initialize the document.
        Parameters:
        - index of open documents (from list_visio_drawings), or a file name, or a visio document object, or none
        - if document = None, use create_new=True (optionally Template = "your-template")
        - no parameters opens a dialog with the option to choose from file picker'''
        msg += "\nvdoc, vapp, vpg, vwin = vDoc.doc, vDoc.app, vDoc.page, vDoc.win"
        print(msg)

    def init(self, document=None, create_new=False, template=None):
        """
        Initialize the Visio application and set vDoc, vApp, vPg, and vWin.

        Parameters:
        - document: Can be an index (int), file path (str), or Visio document object.
        - create_new: Boolean to create a new document.
        - template: Template file path for creating a new document.
        """
        if create_new:
            self.doc = self.create_new_document(template)
        elif document is not None:
            if isinstance(document, int):
                docs = list_visio_drawings()
                if 0 <= document < len(docs):
                    self.doc = docs[document]
                else:
                    raise ValueError("Invalid document index.")
            elif isinstance(document, str):
                self.doc = self.open_visio_file(document)
            elif hasattr(document, 'Application'):
                self.doc = document
            else:
                raise ValueError("Invalid document parameter.")
        else:
            raise ValueError("No document specified.")

        self.app = self.doc.Application
        self.page = list(self.doc.Pages)[0]
        self.win = self.app.ActiveWindow

        print(f"Visio document initialized: {self.doc.Name}")

    def create_new_document(self, template=None):
        if self.visio is None:
            self.visio = win32com.client.Dispatch("Visio.Application")

        if template:
            doc = self.visio.Documents.Add(template)
        else:
            doc = self.visio.Documents.Add("")
        return doc

    def open_visio_file(self, file_path=None):
        if file_path is None:
            root = tk.Tk()
            root.withdraw()
            file_path = filedialog.askopenfilename(
                title="Select a Visio file",
                filetypes=[("Visio files", "*.vsd;*.vsdx")]
            )
            print(f"Selected file path: {file_path}")  # Debugging line

        if file_path:
            file_path = os.path.normpath(file_path)
            print(f"Normalized file path: {file_path}")  # Debugging line

            if not os.path.isfile(file_path):
                raise FileNotFoundError(f"File does not exist: {file_path}")

            visio = win32com.client.Dispatch("Visio.Application")
            try:
                doc = visio.Documents.Open(file_path)
                return doc
            except Exception as e:
                raise Exception(f"Error opening file: {e}")
        else:
            raise ValueError("No file selected.")

    def save(self, file_path):
        if self.doc:
            self.doc.SaveAs(file_path)
            print(f"Document saved as {file_path}")
        else:
            raise ValueError("No document to save.")

    def close(self):
        if self.doc:
            self.doc.Close()
            self.doc = None
            self.app = None
            self.page = None
            self.win = None
            print("Document closed.")
        else:
            raise ValueError("No document to close.")

    def list_pages(self):
        if self.doc:
            for i, page in enumerate(self.doc.Pages):
                print(f"{i}: {page.Name}")
        else:
            raise ValueError("No document open.")

    def switch_page(self, page_index):
        if self.doc and 0 <= page_index < len(self.doc.Pages):
            self.page = self.doc.Pages[page_index]
            self.page.Activate()
            print(f"Switched to page: {self.page.Name}")
        else:
            raise ValueError("Invalid page index.")

    def get_active_page(self):
        return self.page

    def get_active_window(self):
        return self.win
