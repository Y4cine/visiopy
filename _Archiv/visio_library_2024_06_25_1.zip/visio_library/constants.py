from collections import defaultdict

def print_constants(constants):
    constants_dict = constants.__dict__['__dicts__'][0]
    keyword_groups = defaultdict(list)
    keywords = ['visSection', 'visRow', 'visCell', 'visLayer', 'visShape', 'visWindow', 'visDocument']

    for name, value in constants_dict.items():
        added = False
        for keyword in keywords:
            if keyword in name:
                keyword_groups[keyword].append((name, value))
                added = True
                break
        if not added:
            keyword_groups['Others'].append((name, value))

    for keyword, items in keyword_groups.items():
        print(f"\nConstants related to {keyword}:")
        for name, value in sorted(items):
            print(f"  {name}: {value}")
