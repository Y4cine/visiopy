import win32com.client
import pythoncom
import tkinter as tk
from tkinter import filedialog
import os


def list_visio_drawings():
    '''Returns the list of open Visio drawings as list of documents.'''
    visio_documents = []
    visio_clsid = "{00021A21-0000-0000-C000-000000000046}"

    context = pythoncom.CreateBindCtx(0)
    rot = pythoncom.GetRunningObjectTable()
    for moniker in rot:
        try:
            name = moniker.GetDisplayName(context, None)
            if visio_clsid in name or name.endswith('.vsdx') or name.endswith('.vsdm'):
                visio_documents.append(moniker)
        except Exception as e:
            print(f"Error processing moniker: {e}")

    visio_apps = []
    drawing_objects = []

    for moniker in visio_documents:
        try:
            visio_doc = moniker.BindToObject(
                context, None, pythoncom.IID_IDispatch)
            visio_doc = win32com.client.Dispatch(visio_doc)
            visio_app = visio_doc.Application
            if visio_app not in visio_apps:
                visio_apps.append(visio_app)
        except Exception as e:
            print(f"Error accessing Visio application from moniker: {e}")

    for visio_app in visio_apps:
        try:
            for doc in visio_app.Documents:
                if not (doc.FullName.endswith('.vss') or doc.FullName.endswith('.vssx') or doc.FullName.endswith('.vssm')):
                    drawing_objects.append(doc)
        except Exception as e:
            print(f"Error accessing documents from application: {e}")

    # for drawing in drawing_objects:
    #     print(drawing.Name)
    return drawing_objects


def open_visio_file(file_path=None):
    if file_path is None:
        root = tk.Tk()
        root.withdraw()
        file_path = filedialog.askopenfilename(
            title="Select a Visio file",
            filetypes=[("Visio files", "*.vsd;*.vsdx")]
        )
        print(f"Selected file path: {file_path}")  # Debugging line

    if file_path:
        # Normalize and quote the file path to handle spaces and special characters
        file_path = os.path.normpath(file_path)
        print(f"Normalized file path: {file_path}")  # Debugging line

        # Check if the file exists
        if not os.path.isfile(file_path):
            print(f"File does not exist: {file_path}")
            return None

        visio = win32com.client.Dispatch("Visio.Application")
        try:
            doc = visio.Documents.Open(file_path)
            return doc
        except Exception as e:
            print(f"Error opening file: {e}")  # Debugging line
            return None
    else:
        print("No file selected.")
        return None
