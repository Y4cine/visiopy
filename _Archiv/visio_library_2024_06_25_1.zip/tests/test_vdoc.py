import unittest
from visio_library import vDocClass, list_visio_drawings

class TestVisioManager(unittest.TestCase):
    def setUp(self):
        self.visio_manager = vDocClass()

    def test_list_visio_drawings(self):
        drawings = list_visio_drawings()
        self.assertIsInstance(drawings, list)

if __name__ == '__main__':
    unittest.main()
