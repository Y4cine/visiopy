import sys
#sys.path.insert(0, './visio_library')

from visio_library.helpers import open_visio_file

# Test opening a Visio file
vDoc = open_visio_file()  # This should prompt for a file selection
