import sys
sys.path.insert(0, './visio_library')

from visio_library import vDocClass, list_visio_drawings, open_visio_file

# Initialize the VisioManager
visio_manager = vDocClass()

# List open Visio drawings
drawings = list_visio_drawings()
for i, drawing in enumerate(drawings):
    print(f"{i}: {drawing.FullName}")

# Open a specific file (provide a valid path to a Visio file)
# visio_manager.vIniDoc(document="path/to/your/file.vsdx")

# Create a new document
visio_manager.vIniDoc(create_new=True)
