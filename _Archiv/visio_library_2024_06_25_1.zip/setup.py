from setuptools import setup, find_packages

setup(
    name='visio_library',
    version='0.1',
    packages=find_packages(),
    install_requires=['pywin32'],
    description='A library to automate Visio operations.',
    author='Yacine',
    author_email='yacine.gacem@gmail.com',
    classifiers=[
        'Programming Language :: Python :: 3',
        'Operating System :: OS Independent',
    ],
)
