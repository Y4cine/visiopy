import sys
sys.path.insert(0, '../visio_library')  # Add the library to the path

from visio_library import VisioManager

visio_manager = VisioManager()
drawings = visio_manager.list_visio_drawings()
print(drawings)

